#-------------------------------------------------------------------------------
# Name:        Save Data
# Author:      Dhiabi Fathi
# Created:     26/06/2020
# Copyright:   (c) PyAMS 2020
# Licence:     free
#-------------------------------------------------------------------------------



import  PyAMS
from PyAMS import time,freq;
from option import simulationOption;




def AddToData(outPut,analysis):
    global time
    '''
    if analysis['mode']=='tran':
        time.data=[];
        for i in range(len(outPut)):
            outPut[i].data=[];
    '''



def SaveInData(outPut,analysis):
    global time;
    '''
    if analysis['mode']=='tran':
        time.data+=[time.Val];
        for i in range(len(outPut)):
            outPut[i].data+=[outPut[i].Val];
    '''












