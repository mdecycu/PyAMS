#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      asus
#
# Created:     12/10/2021
# Copyright:   (c) asus 2021
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    import SymbolEditor;
    SymbolEditor.exec();

if __name__ == '__main__':
    main()
